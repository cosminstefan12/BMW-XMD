# BMW-XMD V5

## Local
npm install
npm start
Open http://localhost:3000 → enter the pair code in WhatsApp → Linked devices → Link with phone number.

## Render
1. Push this folder to GitHub.
2. Render → New Web Service → Build: `npm install`, Start: `node index.js`.
3. Optional env var `PHONE` (default 40770811929).
4. Add a Persistent Disk mounted at `/opt/render/project/src/auth` so the session survives restarts.
